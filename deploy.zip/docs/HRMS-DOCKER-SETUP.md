# HRMS — Complete Docker Setup (Single Guide)

Everything you need: Docker Hub account → build images → push → deploy on Ubuntu.

| Component | Source path | Docker Hub image (example) |
|-----------|-------------|----------------------------|
| API (.NET 9) | `src/backend_new` | `vishnuksurendran/hrms-api:latest` |
| Frontend (React + Vite) | `src/hrms-frontend_new` | `vishnuksurendran/hrms-frontend:latest` |

Replace `vishnuksurendran` with your Docker Hub username.

---

## Table of contents

1. [Prerequisites](#1-prerequisites)
2. [Docker Hub setup](#2-docker-hub-setup)
3. [Clone the project](#3-clone-the-project)
4. [Project files (copy if missing)](#4-project-files-copy-if-missing)
5. [Build images](#5-build-images)
6. [Push to Docker Hub](#6-push-to-docker-hub)
7. [Ubuntu server setup](#7-ubuntu-server-setup)
8. [Deploy with Docker Compose](#8-deploy-with-docker-compose)
9. [Verify](#9-verify)
10. [Update / redeploy](#10-update--redeploy)
11. [Troubleshooting](#11-troubleshooting)
12. [Quick reference](#12-quick-reference)

---

## 1. Prerequisites

**Build machine (Windows / Linux / macOS)**

| Tool | Version |
|------|---------|
| Git | Any recent |
| Docker Desktop or Docker Engine | 24+ |

**Ubuntu server**

| Tool | Version |
|------|---------|
| Ubuntu | 22.04 or 24.04 LTS |
| Docker Engine + Compose plugin | 24+ |
| Open ports | `5000` (API), `8080` (frontend) |
| PostgreSQL | External DB (e.g. AWS RDS) reachable from server |

---

## 2. Docker Hub setup

### 2.1 Create account

1. Go to [https://hub.docker.com](https://hub.docker.com) and sign up.
2. Note your username (e.g. `vishnuksurendran`).

### 2.2 Create repositories

Create two **public** repos:

- `hrms-api` — .NET backend
- `hrms-frontend` — React frontend (nginx)

Full names: `vishnuksurendran/hrms-api:latest`, `vishnuksurendran/hrms-frontend:latest`

### 2.3 Access token (recommended)

Docker Hub → **Account Settings** → **Security** → **New Access Token** → Read/Write/Delete → save the token.

### 2.4 Login

```bash
docker login
```

Use username + access token (not your account password in scripts).

---

## 3. Clone the project

```bash
git clone <your-repo-url> hrms-staging
cd hrms-staging
```

---

## 4. Project files (copy if missing)

These files already exist in the repo. If you are setting up on a fresh machine, create them exactly as below.

### 4.1 `src/backend_new/Dockerfile`

```dockerfile
FROM mcr.microsoft.com/dotnet/sdk:9.0 AS build
WORKDIR /src

COPY Hrms.NewApi/Hrms.NewApi.csproj Hrms.NewApi/
RUN dotnet restore Hrms.NewApi/Hrms.NewApi.csproj

COPY Hrms.NewApi/ Hrms.NewApi/
WORKDIR /src/Hrms.NewApi
RUN dotnet publish Hrms.NewApi.csproj -c Release -o /app/publish /p:UseAppHost=false

FROM mcr.microsoft.com/dotnet/aspnet:9.0 AS final
WORKDIR /app

RUN apt-get update \
    && apt-get install -y --no-install-recommends curl \
    && rm -rf /var/lib/apt/lists/*

EXPOSE 80
ENV ASPNETCORE_URLS=http://+:80

COPY --from=build /app/publish .

ENTRYPOINT ["dotnet", "Hrms.NewApi.dll"]
```

### 4.2 `src/backend_new/.dockerignore`

```gitignore
**/bin/
**/obj/
**/publish/
**/.vs/
**/*.user
**/*.suo
**/appsettings.Development.json
.git/
.gitignore
```

### 4.3 `src/hrms-frontend_new/Dockerfile`

```dockerfile
FROM node:22-alpine AS build
WORKDIR /app

COPY package.json package-lock.json ./
RUN npm ci

COPY . .

ARG VITE_API_BASE_URL=http://localhost:6001/api
ENV VITE_API_BASE_URL=$VITE_API_BASE_URL

RUN npm run build

FROM nginx:alpine AS final
COPY nginx.conf /etc/nginx/conf.d/default.conf
COPY --from=build /app/dist /usr/share/nginx/html

EXPOSE 80
```

### 4.4 `src/hrms-frontend_new/nginx.conf`

```nginx
server {
    listen 80;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

### 4.5 `src/hrms-frontend_new/.dockerignore`

```gitignore
node_modules/
dist/
.git/
.gitignore
*.md
```

### 4.6 `deploy/docker-compose.yml`

```yaml
services:
  db-probe:
    image: postgres:16-alpine
    container_name: hrms-db-probe
    restart: unless-stopped
    environment:
      PGPASSWORD: "${DB_PASSWORD}"
    command: ["sh", "-c", "sleep infinity"]
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -h ${DB_HOST} -p ${DB_PORT} -U ${DB_USER} -d ${DB_NAME}"]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 20s

  hrms-api:
    image: vishnuksurendran/hrms-api:latest
    container_name: hrms-api
    restart: unless-stopped
    env_file:
      - .env
    depends_on:
      db-probe:
        condition: service_healthy
    environment:
      ASPNETCORE_ENVIRONMENT: Production
      ConnectionStrings__DefaultConnection: "Host=${DB_HOST};Port=${DB_PORT};Database=${DB_NAME};Username=${DB_USER};Password=${DB_PASSWORD};SSL Mode=Require;Trust Server Certificate=true"
      Cors__AllowedOrigins__0: "${FRONTEND_URL}"
    ports:
      - "${API_PORT:-5000}:80"
    healthcheck:
      test: ["CMD-SHELL", "curl -fsS http://localhost/health || exit 1"]
      interval: 30s
      timeout: 5s
      retries: 5
      start_period: 40s
    logging:
      driver: json-file
      options:
        max-size: "10m"
        max-file: "3"

  hrms-frontend:
    image: vishnuksurendran/hrms-frontend:latest
    container_name: hrms-frontend
    restart: unless-stopped
    depends_on:
      hrms-api:
        condition: service_healthy
    ports:
      - "${FRONTEND_PORT:-8080}:80"
    logging:
      driver: json-file
      options:
        max-size: "10m"
        max-file: "3"
```

### 4.7 `deploy/.env` (create on server — do not commit)

```env
DB_HOST=your-rds-host.ap-south-1.rds.amazonaws.com
DB_PORT=5432
DB_NAME=HRMS-Live
DB_USER=postgres
DB_PASSWORD=your-secure-password

# Must match browser URL exactly — no trailing slash
FRONTEND_URL=http://YOUR_SERVER_IP:8080

API_PORT=5000
FRONTEND_PORT=8080
```

---

## 5. Build images

Set your values first.

**Linux / macOS:**

```bash
export DOCKER_USER=vishnuksurendran
export PUBLIC_API_URL=http://YOUR_SERVER_IP:5000/api
```

**Windows PowerShell:**

```powershell
$env:DOCKER_USER = "vishnuksurendran"
$env:PUBLIC_API_URL = "http://YOUR_SERVER_IP:5000/api"
```

### Build API

```bash
docker build -t ${DOCKER_USER}/hrms-api:latest -f src/backend_new/Dockerfile src/backend_new
```

PowerShell:

```powershell
docker build -t "$env:DOCKER_USER/hrms-api:latest" -f src/backend_new/Dockerfile src/backend_new
```

### Build frontend

`VITE_API_BASE_URL` is baked in at build time — use the URL browsers will call.

```bash
docker build \
  --build-arg VITE_API_BASE_URL=${PUBLIC_API_URL} \
  -t ${DOCKER_USER}/hrms-frontend:latest \
  -f src/hrms-frontend_new/Dockerfile src/hrms-frontend_new
```

PowerShell:

```powershell
docker build --build-arg VITE_API_BASE_URL=$env:PUBLIC_API_URL `
  -t "$env:DOCKER_USER/hrms-frontend:latest" `
  -f src/hrms-frontend_new/Dockerfile src/hrms-frontend_new
```

### Optional local API test

```bash
docker run --rm -p 5000:80 \
  -e ASPNETCORE_ENVIRONMENT=Production \
  -e ConnectionStrings__DefaultConnection="Host=...;Port=5432;Database=...;Username=...;Password=...;SSL Mode=Require;Trust Server Certificate=true" \
  -e Cors__AllowedOrigins__0="http://localhost:8080" \
  vishnuksurendran/hrms-api:latest

curl http://localhost:5000/health
```

---

## 6. Push to Docker Hub

```bash
docker push ${DOCKER_USER}/hrms-api:latest
docker push ${DOCKER_USER}/hrms-frontend:latest
```

PowerShell:

```powershell
docker push "$env:DOCKER_USER/hrms-api:latest"
docker push "$env:DOCKER_USER/hrms-frontend:latest"
```

Optional version tag:

```bash
docker tag ${DOCKER_USER}/hrms-api:latest ${DOCKER_USER}/hrms-api:1.0.0
docker push ${DOCKER_USER}/hrms-api:1.0.0
```

---

## 7. Ubuntu server setup

```bash
ssh ubuntu@YOUR_SERVER_IP
```

### Install Docker

```bash
sudo apt-get update
sudo apt-get install -y ca-certificates curl gnupg

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo usermod -aG docker $USER
```

Log out and back in, then verify:

```bash
docker --version
docker compose version
```

### Firewall (if UFW enabled)

```bash
sudo ufw allow 22/tcp
sudo ufw allow 5000/tcp
sudo ufw allow 8080/tcp
sudo ufw enable
```

Also open ports in your cloud security group (AWS/Azure).

### Docker login (private images only)

```bash
docker login
```

Public images do not require login on the server.

---

## 8. Deploy with Docker Compose

```bash
mkdir -p ~/hrms-deploy
cd ~/hrms-deploy
```

Copy `deploy/docker-compose.yml` here. Create `.env` (see section 4.7).

```bash
nano .env          # fill DB_* and FRONTEND_URL
docker compose pull
docker compose up -d
docker compose ps
```

| Service | Role |
|---------|------|
| `db-probe` | Waits until external PostgreSQL is reachable |
| `hrms-api` | API on host port `5000` |
| `hrms-frontend` | React app on host port `8080` |

### API-only (frontend on CDN / CloudFront)

Remove the `hrms-frontend` service from compose. Set:

```env
FRONTEND_URL=https://d3kk9sy2jlgk3d.cloudfront.net
```

(no trailing slash)

---

## 9. Verify

```bash
curl http://localhost:5000/health
# {"status":"healthy"}

docker compose logs hrms-api | grep -i migration
# Database migrations applied successfully.
```

Browser: `http://YOUR_SERVER_IP:8080`

Login requires CORS `FRONTEND_URL` to match the browser address exactly.

---

## 10. Update / redeploy

**Build machine:**

```bash
git pull
docker build -t ${DOCKER_USER}/hrms-api:latest -f src/backend_new/Dockerfile src/backend_new
docker push ${DOCKER_USER}/hrms-api:latest
```

Rebuild frontend only if API URL changed:

```bash
docker build --build-arg VITE_API_BASE_URL=${PUBLIC_API_URL} \
  -t ${DOCKER_USER}/hrms-frontend:latest \
  -f src/hrms-frontend_new/Dockerfile src/hrms-frontend_new
docker push ${DOCKER_USER}/hrms-frontend:latest
```

**Server:**

```bash
cd ~/hrms-deploy
docker compose pull
docker compose up -d
```

---

## 11. Troubleshooting

| Problem | Fix |
|---------|-----|
| `db-probe` unhealthy | Check `.env` DB values; allow server IP in RDS security group |
| API exits on start | `docker compose logs hrms-api` — wrong connection string or DB permissions |
| CORS / login fails | `FRONTEND_URL` must match browser URL exactly; check `docker compose logs hrms-api \| grep -i cors` |
| Frontend API errors | Rebuild frontend with correct `VITE_API_BASE_URL` |
| Cannot pull images | `docker login` (private repos) or verify image name/tag in compose |
| Port in use | Change `API_PORT` / `FRONTEND_PORT` in `.env` |

Test DB from probe container:

```bash
docker compose exec db-probe pg_isready -h $DB_HOST -p 5432 -U postgres -d HRMS-Live
```

---

## 12. Quick reference

```bash
# ── Build machine ──────────────────────────────────────────
docker login
export DOCKER_USER=vishnuksurendran
export PUBLIC_API_URL=http://SERVER_IP:5000/api

docker build -t $DOCKER_USER/hrms-api:latest -f src/backend_new/Dockerfile src/backend_new
docker build --build-arg VITE_API_BASE_URL=$PUBLIC_API_URL \
  -t $DOCKER_USER/hrms-frontend:latest -f src/hrms-frontend_new/Dockerfile src/hrms-frontend_new

docker push $DOCKER_USER/hrms-api:latest
docker push $DOCKER_USER/hrms-frontend:latest

# ── Ubuntu server ──────────────────────────────────────────
mkdir -p ~/hrms-deploy && cd ~/hrms-deploy
# place docker-compose.yml + .env here
docker compose pull && docker compose up -d
curl http://localhost:5000/health
```

### Production tips

1. Use HTTPS (reverse proxy or load balancer).
2. Tag releases (`hrms-api:1.0.0`) instead of only `latest`.
3. Never commit `.env` with real passwords.
4. Restrict PostgreSQL to the app server IP only.
5. For same-origin cookies over HTTPS, proxy API + frontend under one domain.
